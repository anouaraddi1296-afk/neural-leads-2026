import cloudscraper
import re

def extract_emails(url):
    print(f"\n[+] Scanning (Stealth Mode): {url}")
    
    # إنشاء متصفح وهمي يتخطى حماية Cloudflare
    scraper = cloudscraper.create_scraper(browser={
        'browser': 'chrome',
        'platform': 'windows',
        'desktop': True
    })
    
    try:
        response = scraper.get(url)
        
        # استخدام التعابير النمطية (Regex) لاستخراج الإيميلات
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        emails = set(re.findall(email_pattern, response.text))
        
        if emails:
            print(f"[✔] Found {len(emails)} emails:")
            for email in emails:
                print(f"    -> {email}")
        else:
            print("[-] No emails found on this page directly.")
            
    except Exception as e:
        print(f"[X] Error: {e}")

if __name__ == "__main__":
    print("=== OSINT Email Extractor v2.0 ===")
    # سنجرب الموقع الأول الذي فشل سابقاً
    test_url = "https://smilesdental.com/contact-us/"
    extract_emails(test_url)
