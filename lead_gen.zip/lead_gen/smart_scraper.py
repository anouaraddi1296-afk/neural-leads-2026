import cloudscraper
import re
from bs4 import BeautifulSoup

def extract_emails_smart(url):
    print(f"\n[+] Scanning for 'mailto' and emails: {url}")
    
    scraper = cloudscraper.create_scraper(browser={'browser': 'chrome', 'platform': 'windows'})
    
    try:
        response = scraper.get(url, timeout=15)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 1. البحث عن روابط mailto (الطريقة الأقوى)
        mailto_links = soup.find_all('a', href=re.compile(r'^mailto:'))
        emails = set()
        
        for link in mailto_links:
            email = link.get('href').replace('mailto:', '').split('?')[0]
            emails.add(email)
            
        # 2. البحث عن نصوص الإيميلات العادية
        text_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        text_emails = set(re.findall(text_pattern, response.text))
        emails.update(text_emails)
        
        if emails:
            print(f"[✔] Found {len(emails)} email(s):")
            for email in emails:
                print(f"    -> {email}")
        else:
            print("[-] No emails found. Site probably uses a contact form only.")
            
    except Exception as e:
        print(f"[X] Error: {e}")

if __name__ == "__main__":
    print("=== SMART OSINT Email Extractor ===")
    # جرب موقعاً آخر (مثلاً عيادة في المغرب أو موقع أبسط)
    test_url = "https://www.dentalcare.com/en-us/contact-us" # موقع آخر
    extract_emails_smart(test_url)
